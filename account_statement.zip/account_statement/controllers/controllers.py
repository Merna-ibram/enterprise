# -*- coding: utf-8 -*-
# from odoo import http


# class ../custom-addons/accountMove(http.Controller):
#     @http.route('/../custom-addons/account_move/../custom-addons/account_move', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/../custom-addons/account_move/../custom-addons/account_move/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('../custom-addons/account_move.listing', {
#             'root': '/../custom-addons/account_move/../custom-addons/account_move',
#             'objects': http.request.env['../custom-addons/account_move.../custom-addons/account_move'].search([]),
#         })

#     @http.route('/../custom-addons/account_move/../custom-addons/account_move/objects/<model("../custom-addons/account_move.../custom-addons/account_move"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('../custom-addons/account_move.object', {
#             'object': obj
#         })
