from odoo import _, api, fields, models


class MoveReport(models.TransientModel):
    _name = "move.report.wizard"
    _description = "Move Line Report "

    date_from = fields.Date(required=True)
    date_to = fields.Date(required=True)
    partner_id = fields.Many2one('res.partner', string='customer', required=True)

    def action_print_report(self):
        vals = []
        move_ids = self.env['account.move.line'].search([
            ('partner_id', '=', self.partner_id.id),
            ('account_id.user_type_id.type', '=', 'receivable'),
            ('move_id.state', '=', 'posted'),
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to)], order='id ASC')
        balance = 0
        t_debit = sum(move_ids.mapped("debit"))
        t_credit = sum(move_ids.mapped("credit"))
        for move in move_ids:
            balance = balance + move.debit - move.credit
            vals.append({
                'date': move.date,
                'partner': move.partner_id.name,
                'Reference': move.name,
                'Debit': move.debit,
                'Credit': move.credit,
                'balance': balance,
            })
        data = {
            'ids': self.ids,
            'model': "move.report.wizard",
            'vals': vals,
            'date_to': self.date_to,
            'date_from': self.date_from,
            'partner_id': self.partner_id.name,
            't_debit': t_debit,
            't_credit': t_credit,
        }
        return self.env.ref('account_statement.move_details_report').report_action(self, data=data)