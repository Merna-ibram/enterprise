# -*- coding: utf-8 -*-
{
    'name': 'Easy Orders Connector',
    'version': '1.0.0',
    'summary': 'Sync products, categories, orders and designs with Easy Orders',
    'category': 'eCommerce',
    'author': 'Auto-generated',
    'license': 'LGPL-3',
    'depends': ['base','product','sale','stock','website_sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/easy_instance_views.xml',
        'views/easy_product_views.xml',
        'views/easy_category_views.xml',
        'views/easy_order_views.xml',
        'views/menu.xml',
        'data/cron_data.xml',
    ],
    'installable': True,
    'application': False,
}
