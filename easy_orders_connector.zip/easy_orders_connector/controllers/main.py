# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import json

class EasyOrdersController(http.Controller):

    @http.route('/easy_orders/webhook', type='json', auth='public', methods=['POST'], csrf=False)
    def webhook(self, **post):
        payload = request.httprequest.get_data(as_text=True)
        try:
            data = json.loads(payload)
        except Exception:
            return {'error': 'invalid json'}

        event = data.get('event') or data.get('type')
        obj = data.get('data') or {}

        inst = request.env['easy.orders.instance'].sudo().search([], limit=1)
        if not inst:
            return {'error': 'no instance configured'}

        if event and 'order' in event:
            request.env['easy.orders.order'].sudo().sync_from_payload(obj, inst.id)
            return {'ok': True}

        if event and 'product' in event:
            request.env['easy.orders.product'].sudo().sync_from_payload(obj, inst.id)
            return {'ok': True}

        if event and 'category' in event:
            request.env['easy.orders.category'].sudo().sync_from_payload(obj, inst.id)
            return {'ok': True}

        return {'ok': False, 'message': 'unhandled_event'}
