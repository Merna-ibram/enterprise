from . import easy_instance
from . import easy_category
from . import easy_product
from . import easy_order
