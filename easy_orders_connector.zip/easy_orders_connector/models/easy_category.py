# -*- coding: utf-8 -*-
from odoo import models, fields, api

class EasyCategory(models.Model):
    _name = 'easy.orders.category'
    _description = 'Easy Orders Category'

    name = fields.Char(required=True)
    easy_id = fields.Char(string='Easy Orders ID', index=True)
    parent_id = fields.Many2one('easy.orders.category', string='Parent')
    odoo_categ_id = fields.Many2one('product.category', string='Odoo category')
    instance_id = fields.Many2one('easy.orders.instance', string='Instance', required=True, ondelete='cascade')

    def sync_from_easy(self):
        for inst in self.mapped('instance_id'):
            data = {}
            try:
                data = inst.request_get('/api/v1/external-apps/categories')
            except Exception:
                continue
            for item in data.get('data', []):
                vals = {
                    'name': item.get('name') or item.get('title'),
                    'easy_id': str(item.get('id')),
                    'instance_id': inst.id,
                }
                rec = self.search([('easy_id','=',str(item.get('id'))),('instance_id','=',inst.id)], limit=1)
                if rec:
                    rec.write(vals)
                else:
                    self.create(vals)

    def sync_from_payload(self, payload, instance_id):
        # Accepts single payload dict from webhook
        vals = {
            'name': payload.get('name') or payload.get('title'),
            'easy_id': str(payload.get('id')),
            'instance_id': instance_id,
        }
        rec = self.search([('easy_id','=',vals['easy_id']),('instance_id','=',instance_id)], limit=1)
        if rec:
            rec.write(vals)
        else:
            self.create(vals)
