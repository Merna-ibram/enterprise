# -*- coding: utf-8 -*-
from odoo import models, fields, api
import requests, json

class EasyOrdersInstance(models.Model):
    _name = 'easy.orders.instance'
    _description = 'Easy Orders Instance'

    name = fields.Char(required=True)
    api_key = fields.Char(string='API Key')
    store_link = fields.Char(string='Store Link', help='Base API URL for Easy Orders')
    active = fields.Boolean(default=True)
    last_sync = fields.Datetime()

    def _get_headers(self):
        return {
            'Api-Key': self.api_key or '',
            'Content-Type': 'application/json'
        }

    def request_get(self, path, params=None):
        url = (self.store_link or '').rstrip('/') + '/' + path.lstrip('/')
        resp = requests.get(url, headers=self._get_headers(), params=params or {}, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def request_post(self, path, data=None):
        url = (self.store_link or '').rstrip('/') + '/' + path.lstrip('/')
        resp = requests.post(url, headers=self._get_headers(), json=data or {}, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def sync_all(self):
        # entry point for cron. sync categories, products, orders for each instance
        for inst in self.search([('active','=',True)]):
            try:
                self.env['easy.orders.category'].sudo().search([('instance_id','=',inst.id)]).sync_from_easy()
                self.env['easy.orders.product'].sudo().search([('instance_id','=',inst.id)]).sync_from_easy()
                self.env['easy.orders.order'].sudo().search([('instance_id','=',inst.id)]).sync_from_easy()
                inst.write({'last_sync': fields.Datetime.now()})
            except Exception as e:
                _logger = self.env['ir.logging'] if hasattr(self.env, 'ir') else None
                # silent fail; real module should log
