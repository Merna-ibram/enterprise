# -*- coding: utf-8 -*-
from odoo import models, fields, api

class EasyOrderLine(models.Model):
    _name = 'easy.orders.order.line'
    _description = 'Easy Orders Order Line'

    order_id = fields.Many2one('easy.orders.order', ondelete='cascade')
    product_easy_id = fields.Char()
    product_id = fields.Many2one('product.template')
    name = fields.Char()
    qty = fields.Float()
    price_unit = fields.Float()

class EasyOrder(models.Model):
    _name = 'easy.orders.order'
    _description = 'Easy Orders Order'

    name = fields.Char(string='Order Reference')
    easy_id = fields.Char(index=True)
    instance_id = fields.Many2one('easy.orders.instance', required=True, ondelete='cascade')
    partner_id = fields.Many2one('res.partner', string='Customer')
    state = fields.Selection([('draft','Draft'),('confirmed','Confirmed'),('done','Done')], default='draft')
    lines = fields.One2many('easy.orders.order.line','order_id')

    def sync_from_easy(self):
        for inst in self.mapped('instance_id'):
            try:
                data = inst.request_get('/api/v1/external-apps/orders')
            except Exception:
                continue
            for item in data.get('data', []):
                self._create_or_update_from_payload(item, inst.id)

    def sync_from_payload(self, payload, instance_id):
        self._create_or_update_from_payload(payload, instance_id)

    def _create_or_update_from_payload(self, item, inst_id):
        easy_id = str(item.get('id'))
        vals = {
            'name': item.get('reference') or ('EO/%s' % easy_id),
            'easy_id': easy_id,
            'instance_id': inst_id,
        }
        rec = self.search([('easy_id','=',easy_id),('instance_id','=',inst_id)], limit=1)
        if rec:
            rec.write(vals)
        else:
            rec = self.create(vals)
        # partner
        cust = item.get('customer') or {}
        partner = self.env['res.partner'].search([('email','=',cust.get('email'))], limit=1)
        if not partner:
            partner = self.env['res.partner'].create({'name': cust.get('name') or 'Guest','email':cust.get('email')})
        rec.partner_id = partner.id
        # replace lines
        rec.lines.unlink()
        for ln in item.get('items', []) or item.get('lines', []):
            product_easy_id = str(ln.get('product_id') or ln.get('id') or ln.get('product'))
            prod = self.env['easy.orders.product'].search([('easy_id','=',product_easy_id),('instance_id','=',inst_id)], limit=1)
            self.env['easy.orders.order.line'].create({
                'order_id': rec.id,
                'product_easy_id': product_easy_id,
                'name': ln.get('name') or ln.get('title'),
                'qty': float(ln.get('quantity') or ln.get('qty') or 1.0),
                'price_unit': float(ln.get('price') or ln.get('price_unit') or 0.0),
                'product_id': prod.odoo_product_id.id if prod and prod.odoo_product_id else False,
            })
