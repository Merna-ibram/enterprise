# -*- coding: utf-8 -*-
from odoo import models, fields, api
import base64, requests

class EasyProduct(models.Model):
    _name = 'easy.orders.product'
    _description = 'Easy Orders Product'

    name = fields.Char(required=True)
    easy_id = fields.Char(index=True)
    instance_id = fields.Many2one('easy.orders.instance', required=True, ondelete='cascade')
    odoo_product_id = fields.Many2one('product.template', string='Odoo Template')
    sku = fields.Char()
    price = fields.Float()
    image = fields.Binary()

    def sync_from_easy(self):
        for inst in self.mapped('instance_id'):
            params = {'join':'categories,variants'}
            try:
                data = inst.request_get('/api/v1/external-apps/products', params=params)
            except Exception:
                continue
            for item in data.get('data', []):
                easy_id = str(item.get('id'))
                vals = {
                    'name': item.get('name') or item.get('title'),
                    'easy_id': easy_id,
                    'instance_id': inst.id,
                    'sku': item.get('sku') or item.get('code'),
                    'price': float(item.get('price') or 0.0),
                }
                rec = self.search([('easy_id','=',easy_id),('instance_id','=',inst.id)], limit=1)
                if rec:
                    rec.write(vals)
                else:
                    rec = self.create(vals)

                template_vals = {
                    'name': rec.name,
                    'list_price': rec.price,
                }
                if rec.odoo_product_id:
                    rec.odoo_product_id.write(template_vals)
                else:
                    template = self.env['product.template'].create(template_vals)
                    rec.odoo_product_id = template.id

                image_data = item.get('image') or item.get('image_base64') or item.get('images') and item.get('images')[0] or False
                if image_data:
                    try:
                        if isinstance(image_data, str) and image_data.startswith('http'):
                            r = requests.get(image_data, timeout=30)
                            if r.ok:
                                rec.image = base64.b64encode(r.content)
                        elif isinstance(image_data, str):
                            rec.image = base64.b64encode(image_data.encode())
                    except Exception:
                        pass

    def sync_from_payload(self, payload, instance_id):
        easy_id = str(payload.get('id'))
        vals = {
            'name': payload.get('name') or payload.get('title'),
            'easy_id': easy_id,
            'instance_id': instance_id,
            'sku': payload.get('sku') or payload.get('code'),
            'price': float(payload.get('price') or 0.0),
        }
        rec = self.search([('easy_id','=',easy_id),('instance_id','=',instance_id)], limit=1)
        if rec:
            rec.write(vals)
        else:
            rec = self.create(vals)
        # sync to product.template
        template_vals = {'name': rec.name, 'list_price': rec.price}
        if rec.odoo_product_id:
            rec.odoo_product_id.write(template_vals)
        else:
            tmpl = self.env['product.template'].create(template_vals)
            rec.odoo_product_id = tmpl.id
