{
    'name': 'Transport Task Number',
    'version': '1.0',
    'summary': 'Add Task Number field to Transport',
    'description': 'Custom module to add task_num field under transaction_type in Transport',
    'category': 'Transport',
    'author': 'Merna',
    'depends': ['transport'],
    'data': [
        'security/ir.model.access.csv',
        'views/transport_task_view.xml',
    ],
    'installable': True,
    'application': False,
}
