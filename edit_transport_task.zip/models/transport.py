from odoo import models, fields

class Transport(models.Model):
    _inherit = 'transport.transport'

    task_num = fields.Char(
        string='رقم الامر',
        required=True
    )
