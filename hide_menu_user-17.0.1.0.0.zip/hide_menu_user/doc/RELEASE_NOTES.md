## Module <hide_menu_user>

#### 24.01.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Hide Any Menu User Wise



