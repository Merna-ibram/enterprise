{
    'name': 'Custom Invoice Template',
    'version': '15.0.1.0.0',
    'summary': 'Custom Tax Invoice Report (Arabic & English)',
    'description': """
        Custom Invoice Template
        A custom Tax Invoice report in Arabic and English with colors, layout, and fonts matching the provided PDF exactly.
        """,
    'author': 'Mirna',
    'category': 'Accounting',
    'depends': ['account'],
    'data': [
        'reports/invoice_tax_report.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
