from odoo import models, fields, api
import base64
import qrcode
from io import BytesIO
from num2words import num2words


class AccountMove(models.Model):
    _inherit = 'account.move'

    invoice_comment = fields.Text(string="Invoice Comment")
    qr_code = fields.Binary("QR Code", compute="_generate_qr_code", store=True, attachment=True)
    amount_in_words_ar = fields.Char(string="Amount in Words (AR)", compute="_compute_amount_in_words", store=True)
    amount_in_words_en = fields.Char(string="Amount in Words (EN)", compute="_compute_amount_in_words", store=True)

    @api.depends('name', 'partner_id.name', 'amount_total', 'currency_id.name', 'state')
    def _generate_qr_code(self):
        for record in self:
            # لو الفاتورة لسه draft أو مفيش بيانات كافية
            if not record.name or record.name == '/' or not record.partner_id or record.state == 'draft':
                record.qr_code = False
                continue

            try:
                data = (
                    f"فاتورة: {record.name}\n"
                    f"العميل: {record.partner_id.name}\n"
                    f"الإجمالي: {record.amount_total:.2f} {record.currency_id.name or ''}"
                )

                qr = qrcode.QRCode(
                    version=1,
                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                    box_size=10,
                    border=4,
                )
                qr.add_data(data)
                qr.make(fit=True)

                img = qr.make_image(fill_color="black", back_color="white")
                buffer = BytesIO()
                img.save(buffer, format='PNG')
                record.qr_code = base64.b64encode(buffer.getvalue())
            except Exception as e:
                record.qr_code = False
                # يمكنك إضافة log للخطأ
                # _logger.error(f"Error generating QR code: {str(e)}")

    @api.depends('amount_total', 'currency_id.name')
    def _compute_amount_in_words(self):
        for invoice in self:
            if invoice.amount_total and invoice.currency_id:
                try:
                    invoice.amount_in_words_en = num2words(
                        invoice.amount_total,
                        to='currency',
                        lang='en',
                        currency=invoice.currency_id.name
                    ).capitalize()

                    invoice.amount_in_words_ar = (
                            num2words(invoice.amount_total, lang='ar') + " " + invoice.currency_id.name
                    )
                except:
                    invoice.amount_in_words_en = ''
                    invoice.amount_in_words_ar = ''
            else:
                invoice.amount_in_words_en = ''
                invoice.amount_in_words_ar = ''