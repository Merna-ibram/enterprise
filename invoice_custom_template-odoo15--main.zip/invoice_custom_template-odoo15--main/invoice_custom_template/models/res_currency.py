# -*- coding: utf-8 -*-
from odoo import models
from num2words import num2words
import math

class ResCurrency(models.Model):
    _inherit = 'res.currency'

    def _currency_name_ar(self):
        name = (self.name or '').lower()
        if 'riy' in name or 'sar' in name or 'saudi' in name:
            return 'ريال سعودي'
        return 'ريال'

    def amount_to_text_ar(self, amount):
        try:
            amount = float(amount or 0.0)
        except Exception:
            return str(amount)
        integer_part = int(math.floor(amount))
        fraction = int(round((amount - integer_part) * 100))
        try:
            int_words = num2words(integer_part, lang='ar')
        except Exception:
            int_words = str(integer_part)
        try:
            frac_words = num2words(fraction, lang='ar') if fraction else 'صفر'
        except Exception:
            frac_words = str(fraction)
        currency_name = self._currency_name_ar()
        if fraction:
            return f"{int_words} {currency_name} و{frac_words} هللة"
        else:
            return f"{int_words} {currency_name}"
