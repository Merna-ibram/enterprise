{
    'name': 'Easy Order',
    'version': '1.0',
    'summary': 'Connect to Easy Order API',
    'description': 'Manage Easy Order instances and test connection',
    'author': 'Merna',
    'depends': ['product', 'base', 'sale_management'],
    'data': [
        'security/ir.model.access.csv',
        'views/easyorder_instance_views.xml',
        'views/easyorder_operation_wizard_views.xml',
    ],
    'installable': True,
    'application': True,
}
