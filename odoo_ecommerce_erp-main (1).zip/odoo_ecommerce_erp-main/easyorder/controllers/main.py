# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import logging

_logger = logging.getLogger("EasyOrder Webhook")

class EasyOrderWebhookController(http.Controller):

    @http.route(['/easy_orders/webhook'], type='json', auth='public', methods=['POST'], csrf=False)
    def receive_easy_order_webhook(self, **kwargs):
        """
        Webhook handler for Easy Orders.
        يتم استدعاؤه عند إنشاء طلب جديد في Easy Orders.
        """
        try:
            data = request.get_json_data()
            _logger.info("Received EasyOrder Webhook: %s", data)

            order_id = data.get('order_id')
            customer = data.get('customer')
            items = data.get('items', [])

            if not customer or not customer.get("name"):
                _logger.warning("Invalid customer data from EasyOrder: %s", data)
                return {"status": "error", "message": "Invalid customer data"}

            # البحث أو إنشاء العميل
            partner = self._find_or_create_customer(customer)

            # إنشاء أمر البيع
            sale_order = request.env['sale.order'].sudo().create({
                'partner_id': partner.id,
                'origin': f"EasyOrder-{order_id}",
            })

            # إضافة المنتجات فقط إذا كانت موجودة
            for item in items:
                product = request.env['product.product'].sudo().search(
                    [('default_code', '=', item.get('sku'))], limit=1)
                if not product:
                    _logger.warning("Product not found for SKU: %s", item.get('sku'))
                    continue

                request.env['sale.order.line'].sudo().create({
                    'order_id': sale_order.id,
                    'product_id': product.id,
                    'product_uom_qty': item.get('quantity', 1),
                    'price_unit': item.get('price', 0.0),
                })

            _logger.info("Order %s created successfully in Odoo", sale_order.name)
            return {"status": "success", "message": f"Order {sale_order.name} created"}

        except Exception as e:
            _logger.error("EasyOrder Webhook Error: %s", str(e))
            return {"status": "error", "message": str(e)}

    def _find_or_create_customer(self, customer_data):
        """البحث أو إنشاء عميل بناءً على بيانات Easy Orders"""
        name = customer_data.get('name') or 'Unknown Customer'
        phone = customer_data.get('phone')
        email = customer_data.get('email')

        domain = [('name', '=', name)]
        if phone:
            domain = ['|', ('phone', '=', phone), ('mobile', '=', phone)]

        partner = request.env['res.partner'].sudo().search(domain, limit=1)
        if not partner:
            partner = request.env['res.partner'].sudo().create({
                'name': name,
                'phone': phone,
                'mobile': phone,
                'email': email,
                'customer_rank': 1,
            })
            _logger.info("New customer created: %s", name)

        return partner

# from odoo import http
# from odoo.http import request
# import json
# import logging
#
# _logger = logging.getLogger(__name__)
#
#
# class EasyOrdersWebhookController(http.Controller):
#
#     @http.route(['/easy_orders/webhook'], type='json', auth='public', methods=['POST'], csrf=False)
#     def easy_orders_webhook(self, **kwargs):
#         """Receive order data from Easy Orders webhook and create Sale Order in Odoo"""
#         try:
#             # ✅ قراءة بيانات JSON المرسلة
#             data = json.loads(request.httprequest.data.decode('utf-8'))
#             _logger.info("📦 Received Webhook Data: %s", json.dumps(data, indent=2, ensure_ascii=False))
#
#             # 🧾 بيانات العميل
#             partner_vals = {
#                 'name': data.get('full_name'),
#                 'phone': data.get('phone'),
#                 'street': data.get('address'),
#                 'city': data.get('government'),
#             }
#
#             _logger.info("🧾 Creating/Updating partner: %s", partner_vals)
#
#             # 👤 إنشاء أو تحديث العميل
#             partner = request.env['res.partner'].sudo().search([
#                 ('phone', '=', data.get('phone'))
#             ], limit=1)
#
#             if not partner:
#                 partner = request.env['res.partner'].sudo().create(partner_vals)
#                 _logger.info("✅ Partner created: %s", partner.name)
#             else:
#                 partner.sudo().write(partner_vals)
#                 _logger.info("🔁 Partner updated: %s", partner.name)
#
#             # 🔍 التأكد لو الطلب موجود قبل كده
#             sale_order = request.env['sale.order'].sudo().search([
#                 ('easy_order_id', '=', data.get('id'))
#             ], limit=1)
#
#             # ✨ إنشاء الطلب لو مش موجود
#             if not sale_order:
#                 sale_order = request.env['sale.order'].sudo().create({
#                     'partner_id': partner.id,
#                     'easy_order_id': data.get('id'),
#                     'origin': f"EasyOrders {data.get('id')}",
#                     'amount_total': data.get('total_cost', 0.0),
#                 })
#                 _logger.info("🛒 Sale Order created: %s", sale_order.name)
#             else:
#                 sale_order.order_line.unlink()  # تحديث المنتجات لو الطلب مكرر
#                 _logger.info("🔁 Existing Sale Order found: %s - Lines refreshed", sale_order.name)
#
#             # 🛍️ إضافة المنتجات
#             for item in data.get('cart_items', []):
#                 product_data = item.get('product', {})
#                 variant_data = item.get('variant', {})
#
#                 name = product_data.get('name')
#                 sku = variant_data.get('taager_code') or product_data.get('sku')
#                 price = float(item.get('price', 0.0))
#                 qty = float(item.get('quantity', 1))
#
#                 # 🔁 لو الـ SKU مش موجود
#                 if not sku:
#                     sku = f"EO-{item.get('id')}"
#
#                 _logger.info("➕ Adding product line: %s - SKU: %s", name, sku)
#
#                 # 🔍 البحث عن المنتج بالـ SKU
#                 product = request.env['product.product'].sudo().search([
#                     ('default_code', '=', sku)
#                 ], limit=1)
#
#                 if not product:
#                     # إنشاء منتج جديد لو مش موجود
#                     product = request.env['product.product'].sudo().create({
#                         'name': name,
#                         'default_code': sku,
#                         'list_price': price,
#                     })
#                     _logger.info("🆕 Product created: %s (%s)", name, sku)
#
#                 # ➕ إنشاء سطر الطلب
#                 request.env['sale.order.line'].sudo().create({
#                     'order_id': sale_order.id,
#                     'product_id': product.id,
#                     'product_uom_qty': qty,
#                     'price_unit': price,
#                     'name': f"{name} ({sku})",
#                 })
#
#             # 🚚 أضف تكلفة الشحن كـ product line لو فيه
#             shipping_cost = data.get('shipping_cost', 0)
#             if shipping_cost > 0:
#                 _logger.info("🚚 Adding shipping cost: %s", shipping_cost)
#
#                 shipping_product = request.env['product.product'].sudo().search([
#                     ('default_code', '=', 'SHIPPING')
#                 ], limit=1)
#
#                 if not shipping_product:
#                     shipping_product = request.env['product.product'].sudo().create({
#                         'name': 'Shipping Cost',
#                         'default_code': 'SHIPPING',
#                         'list_price': shipping_cost,
#                     })
#                     _logger.info("🆕 Shipping product created")
#
#                 request.env['sale.order.line'].sudo().create({
#                     'order_id': sale_order.id,
#                     'product_id': shipping_product.id,
#                     'product_uom_qty': 1,
#                     'price_unit': shipping_cost,
#                     'name': 'Shipping',
#                 })
#
#             _logger.info("✅ Order %s created successfully from Easy Orders.", sale_order.name)
#             return {
#                 'status': 'success',
#                 'message': f"✅ Order {sale_order.name} created successfully from Easy Orders."
#             }
#
#         except Exception as e:
#             # 🚨 rollback لأي خطأ عشان نمنع Transaction aborted
#             request.env.cr.rollback()
#             _logger.exception("❌ Webhook Error: %s", str(e))
#             return {'status': 'error', 'message': str(e)}

from odoo import models, fields

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    easy_order_id = fields.Char(string="Easy Order ID", copy=False)
