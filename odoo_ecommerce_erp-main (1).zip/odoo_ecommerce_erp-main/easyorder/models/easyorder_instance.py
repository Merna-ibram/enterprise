from odoo import models, fields, api, _
import requests
from odoo.exceptions import UserError

class EasyOrderInstance(models.Model):
    _name = "easy.order.instance"
    _description = "Easy Order Instance"

    name = fields.Char(string="Instance Name", required=True)
    store_link = fields.Char(string="Store Link", required=True)
    api_key = fields.Char(string="API Key", required=True)
    connection_status = fields.Selection([
        ('not_tested', 'Not Tested'),
        ('success', 'Success'),
        ('failed', 'Failed')
    ], string="Connection Status", default='not_tested', readonly=True)
    connection_info = fields.Text(string="Connection Info", readonly=True)

    def action_test_connection(self):
        self.ensure_one()
        try:
            url = "https://api.easy-orders.net/api/v1/external-apps/products"
            headers = {
                "Api-Key": self.api_key,
                "Content-Type": "application/json"
            }
            response = requests.get(url, headers=headers, timeout=10)

            # تحديد النتيجة بشكل مختصر
            if response.status_code == 200:
                self.connection_status = 'success'
                msg = "Connection: success ✅"
            else:
                self.connection_status = 'failed'
                msg = f"Connection failed ({response.status_code}) ❌"

            self.connection_info = response.text

            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Connection Test'),
                    'message': msg,
                    'type': 'success' if self.connection_status == 'success' else 'danger',
                    'sticky': False,
                }
            }

        except Exception as e:
            self.connection_status = 'failed'
            self.connection_info = f"Error: {e}"
            raise UserError(_("Connection error: %s") % e)

