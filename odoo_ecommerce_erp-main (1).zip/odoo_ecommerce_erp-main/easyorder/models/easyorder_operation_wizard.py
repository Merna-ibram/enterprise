from odoo import models, fields, _, api
import requests
import base64
from odoo.exceptions import UserError
import os
import re
import json
from unidecode import unidecode
from datetime import datetime, timedelta


class EasyOrderOperationWizard(models.TransientModel):
    _name = "easy.order.operation.wizard"
    _description = "Easy Order Operation Wizard"

    instance_id = fields.Many2one('easy.order.instance', string="Easy Order Instance", required=True)
    operation = fields.Selection([
        ('import_products', 'Import Products'),
        ('export_products', 'Export Products'),
        ('import_categories', 'Import Categories'),
        ('export_categories', 'Export Categories'),
        ('import_orders', 'Import Orders'),
    ], string="Operation", required=True)

    # حقول استيراد الطلبات
    date = fields.Date(string="Order Date")
    order_import_type = fields.Selection([
        ('single', 'Single Order by ID'),
        ('multiple', 'Multiple Orders by IDs'),
    ], string="Import Type", default='single')
    order_id = fields.Char(string='Order ID', help='Enter single order ID')
    order_ids_text = fields.Text(string='Order IDs', help='Enter multiple order IDs (one per line)')

    @api.onchange('operation')
    def _onchange_operation(self):
        """Show date field only when Import Orders is selected"""
        if self.operation != 'import_orders':
            self.date = False
            self.order_id = False
            self.order_ids_text = False

    def execute_operation(self):
        self.ensure_one()
        if self.operation == 'import_products':
            return self._import_products()
        elif self.operation == 'export_products':
            return self._export_products()
        elif self.operation == 'import_categories':
            return self._import_categories()
        elif self.operation == 'export_categories':
            return self._export_categories()
        elif self.operation == 'import_orders':
            return self._import_orders()
        else:
            return self._show_error(_("Unknown operation"))

    # ================= Export Products =================
    def _export_products(self):
        instance = self.instance_id
        if not instance.store_link or not instance.api_key:
            return self._show_error(_("Please configure the store link and API key for this instance."))

        base_url = "https://api.easy-orders.net/api/v1/external-apps/products"
        headers = {"Api-Key": instance.api_key, "Content-Type": "application/json"}

        products = self.env['product.template'].search([])
        exported, skipped, failed = 0, [], []

        default_img_path = os.path.join(
            os.path.dirname(__file__), "..", "static", "img", "products.png"
        )
        default_img_b64 = None
        if os.path.exists(default_img_path):
            with open(default_img_path, "rb") as f:
                default_img_b64 = base64.b64encode(f.read()).decode("utf-8")

        for prod in products:
            try:
                payload = {
                    "name": prod.name,
                    "price": prod.list_price or 0.0,
                    "cost": prod.standard_price or 0.0,
                    "slug": self._make_slug(prod.name, prod.id),
                }

                if prod.image_1920:
                    payload["thumb"] = base64.b64encode(prod.image_1920).decode("utf-8")
                elif default_img_b64:
                    payload["thumb"] = default_img_b64

                if prod.categ_id:
                    payload["category"] = {
                        "name": prod.categ_id.name,
                        "slug": self._make_slug(prod.categ_id.name, prod.categ_id.id),
                    }

                response = requests.post(base_url, headers=headers, json=payload, timeout=20)

                if response.status_code in (200, 201):
                    exported += 1
                elif response.status_code == 400:
                    try:
                        data = response.json()
                        if data.get("message") == "رابط المنتج محجوز":
                            skipped.append(prod.name)
                            continue
                    except Exception:
                        pass
                    failed.append(f"{prod.name} ({response.status_code})")
                else:
                    failed.append(f"{prod.name} ({response.status_code})")

            except Exception as e:
                failed.append(f"{prod.name} (error: {str(e)})")

        message = _("%s products exported successfully") % exported
        if skipped:
            message += _(", skipped (already exists): %s") % len(skipped)
        if failed:
            message += _(", failed: %s") % len(failed)

        return self._show_success(message)

    # ================= Export Categories =================
    def _export_categories(self):
        instance = self.instance_id
        if not instance.store_link or not instance.api_key:
            return self._show_error(_("Please configure the store link and API key for this instance."))

        base_url = "https://api.easy-orders.net/api/v1/external-apps/categories"
        headers = {"Api-Key": instance.api_key, "Content-Type": "application/json"}

        try:
            existing_resp = requests.get(base_url, headers=headers, timeout=15)
            if existing_resp.status_code != 200:
                return self._show_error(_("Failed to fetch existing categories from Easy Order"))
            existing_data = existing_resp.json()
            existing_names = [c.get("name") for c in existing_data if c.get("name")]
        except Exception as e:
            existing_names = []

        categories = self.env['product.category'].search([])
        exported, skipped, failed = 0, [], []

        default_img_path = os.path.join(os.path.dirname(__file__), "..", "static", "img", "store.png")
        default_img_b64 = None
        if os.path.exists(default_img_path):
            with open(default_img_path, "rb") as f:
                default_img_b64 = base64.b64encode(f.read()).decode("utf-8")

        for cat in categories:
            if cat.name in existing_names:
                skipped.append(cat.name)
                continue

            try:
                payload = {
                    "name": cat.name,
                    "slug": self._make_slug(cat.name, cat.id),
                    "parent_id": None,
                    "show_in_header": False,
                    "position": 0,
                }

                if cat.image_1920:
                    payload["thumb"] = base64.b64encode(cat.image_1920).decode("utf-8")
                elif default_img_b64:
                    payload["thumb"] = default_img_b64

                response = requests.post(base_url, headers=headers, json=payload, timeout=15)

                if response.status_code in (200, 201):
                    exported += 1
                else:
                    failed.append(f"{cat.name} ({response.status_code})")

            except Exception as e:
                failed.append(f"{cat.name} (error)")

        message = _("%s categories exported successfully") % exported
        if skipped:
            message += _(", skipped: %s") % len(skipped)
        if failed:
            message += _(", failed: %s") % len(failed)

        return self._show_success(message)

    # ================= Import Products =================
    def _import_products(self):
        instance = self.instance_id
        if not instance.store_link or not instance.api_key:
            return self._show_error(_("Please configure the store link and API key for this instance."))

        url = "https://api.easy-orders.net/api/v1/external-apps/products?join=categories"
        headers = {"Api-Key": instance.api_key, "Content-Type": "application/json"}

        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code != 200:
                return self._show_error(_("Failed to fetch products. Status: %s") % response.status_code)

            products = response.json()
            created, skipped_products = 0, []

            for prod in products:
                if prod.get('type') == 'variant':
                    continue

                easy_order_id = f"easy order {prod.get('id')}" if prod.get('id') else None
                domain = [('easy_order_id', '=', easy_order_id)] if easy_order_id else [('name', '=', prod.get('name'))]
                existing = self.env['product.template'].search(domain, limit=1)

                if existing:
                    skipped_products.append(prod.get('name'))
                    continue

                vals = {
                    'name': prod.get('name'),
                    'easy_order_id': easy_order_id,
                    'list_price': prod.get('price', 0.0),
                }

                thumb_url = prod.get('thumb')
                if thumb_url:
                    try:
                        img_response = requests.get(thumb_url, timeout=10)
                        if img_response.status_code == 200:
                            vals['image_1920'] = base64.b64encode(img_response.content)
                    except Exception:
                        pass

                category_name = None
                category_data = prod.get('category') or prod.get('categories')
                if isinstance(category_data, dict):
                    category_name = category_data.get('name')
                elif isinstance(category_data, list) and category_data:
                    category_name = category_data[0].get('name')

                if category_name and category_name.strip():
                    category = self.env['product.category'].search([('name', '=', category_name)], limit=1)
                    if not category:
                        category = self.env['product.category'].create({'name': category_name})
                    vals['categ_id'] = category.id

                self.env['product.template'].create(vals)
                created += 1

            message = _("%s products imported successfully") % created
            if skipped_products:
                message += _(", skipped: %s") % len(skipped_products)

            return self._show_success(message)

        except Exception as e:
            return self._show_error(_("Error during products import: %s") % e)

    # ================= Import Categories =================
    def _import_categories(self):
        instance = self.instance_id
        if not instance.store_link or not instance.api_key:
            return self._show_error(_("Please configure the store link and API key for this instance."))

        url = "https://api.easy-orders.net/api/v1/external-apps/categories"
        headers = {"Api-Key": instance.api_key, "Content-Type": "application/json"}

        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code != 200:
                return self._show_error(_("Failed to fetch categories. Status: %s") % response.status_code)

            categories = response.json()
            created, skipped_categories = 0, []

            for cat in categories:
                existing = self.env['product.category'].search([('name', '=', cat.get('name'))], limit=1)
                if existing:
                    skipped_categories.append(cat.get('name'))
                    continue

                self.env['product.category'].create({'name': cat.get('name')})
                created += 1

            message = _("%s categories imported successfully") % created
            if skipped_categories:
                message += _(", skipped: %s") % len(skipped_categories)

            return self._show_success(message)

        except Exception as e:
            return self._show_error(_("Error during categories import: %s") % e)

    # ========================== Import Orders ==========================
    def _import_orders(self):
        """
        ⚠️ Easy Orders API لا يدعم استعلام الطلبات بالتاريخ
        الطريقة الوحيدة: استيراد الطلبات بواسطة Order ID
        """
        instance = self.instance_id
        if not instance.store_link or not instance.api_key:
            raise UserError(_("Please configure the store link and API key for this instance."))

        # استيراد طلب واحد
        if self.order_import_type == 'single':
            if not self.order_id:
                raise UserError(_("Please enter an Order ID"))
            return self._import_single_order(self.order_id.strip())

        # استيراد عدة طلبات
        elif self.order_import_type == 'multiple':
            if not self.order_ids_text:
                raise UserError(_("Please enter Order IDs (one per line)"))
            return self._import_multiple_orders()

        else:
            raise UserError(_(
                "⚠️ Easy Orders API does not support fetching orders by date.\n\n"
                "Please use Order IDs to import orders.\n"
                "You can get Order IDs from Easy Orders dashboard."
            ))

    def _import_single_order(self, order_id):
        """استيراد طلب واحد من Easy Orders"""
        instance = self.instance_id

        # التحقق من وجود الطلب
        existing = self.env['sale.order'].search([('easy_order_id', '=', order_id)], limit=1)
        if existing:
            return self._show_error(_("Order already exists: %s") % existing.name)

        # استدعاء API
        url = f"https://api.easy-orders.net/api/v1/external-apps/orders/{order_id}"
        headers = {
            "Api-Key": instance.api_key,
            "Content-Type": "application/json"
        }

        try:
            response = requests.get(url, headers=headers, timeout=30)

            if response.status_code == 404:
                raise UserError(_("Order not found: %s\nPlease check the Order ID") % order_id)

            if response.status_code == 401:
                raise UserError(_("Authentication failed. Please check your API Key"))

            if response.status_code != 200:
                raise UserError(_("API Error %s: %s") % (response.status_code, response.text))

            order_data = response.json()

            # إنشاء الطلب
            self._create_order_from_api(order_data)

            return self._show_success(_("✅ Order imported successfully: %s") % order_id)

        except requests.exceptions.Timeout:
            raise UserError(_("Request timeout. Please try again."))
        except requests.exceptions.ConnectionError:
            raise UserError(_("Connection error. Please check your internet connection."))
        except Exception as e:
            raise UserError(_("Error importing order:\n%s") % str(e))

    def _import_multiple_orders(self):
        """استيراد عدة طلبات"""
        order_ids = [oid.strip() for oid in self.order_ids_text.split('\n') if oid.strip()]

        if not order_ids:
            raise UserError(_("No valid Order IDs found"))

        success_count = 0
        failed_count = 0
        skipped_count = 0
        errors = []

        for order_id in order_ids:
            try:
                existing = self.env['sale.order'].search([('easy_order_id', '=', order_id)], limit=1)
                if existing:
                    skipped_count += 1
                    continue

                self._import_single_order(order_id)
                success_count += 1

            except Exception as e:
                failed_count += 1
                errors.append(f"{order_id}: {str(e)[:50]}")

        message = _(
            "✅ Import completed:\n\n"
            "🆕 Created: %s\n"
            "⏭️ Skipped (exists): %s\n"
            "❌ Failed: %s"
        ) % (success_count, skipped_count, failed_count)

        if errors:
            message += "\n\n⚠️ Errors (first 3):\n" + "\n".join(errors[:3])

        return self._show_success(message)

    def _create_order_from_api(self, order_data):
        """إنشاء Sale Order من بيانات API"""

        # ====== معالجة التاريخ ======
        date_str = order_data.get('created_at')
        date_order = fields.Datetime.now()
        if date_str:
            try:
                # محاولة تحويل ISO format (مثلاً 2025-10-07T11:53:02.169417Z)
                date_parsed = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                # تحويله لتاريخ بدون timezone (naive)
                date_order = date_parsed.replace(tzinfo=None)
            except Exception:
                try:
                    # fallback لو فشل الأول
                    date_order = datetime.strptime(date_str.split('.')[0].replace('T', ' '), "%Y-%m-%d %H:%M:%S")
                except Exception:
                    date_order = fields.Datetime.now()

        # ====== إنشاء العميل ======
        partner_id = self._find_or_create_customer({
            'name': order_data.get('full_name'),
            'phone': order_data.get('phone'),
            'city': order_data.get('government'),
            'street': order_data.get('address'),
        })

        # ====== إنشاء أمر البيع ======
        sale_order = self.env['sale.order'].create({
            'partner_id': partner_id,
            'easy_order_id': order_data.get('id'),
            'date_order': date_order,
            'easy_order_status': order_data.get('status'),
            'easy_shipping_cost': order_data.get('shipping_cost', 0.0),
            'easy_total_cost': order_data.get('total_cost', 0.0),
            'note': self._format_order_note(order_data),
        })

        # ====== إضافة المنتجات ======
        for item in order_data.get('cart_items', []):
            self._create_order_line_from_api(sale_order, item)

        # ====== إضافة الشحن ======
        shipping_cost = order_data.get('shipping_cost', 0.0)
        if shipping_cost > 0:
            self._add_shipping_line(sale_order, shipping_cost)

        return sale_order

    def _create_order_line_from_api(self, sale_order, item):
        """إنشاء خط طلب من بيانات API"""
        product_data = item.get('product', {})
        product_name = product_data.get('name', 'Unknown Product')

        # البحث عن المنتج
        product = self.env['product.product'].search([
            ('name', '=', product_name)
        ], limit=1)

        # إنشاء المنتج إذا لم يكن موجود
        if not product:
            product = self.env['product.product'].create({
                'name': product_name,
                'type': 'product',
                'list_price': item.get('price', 0.0),
            })

        # إنشاء خط الطلب
        self.env['sale.order.line'].create({
            'order_id': sale_order.id,
            'product_id': product.id,
            'product_uom_qty': item.get('quantity', 1),
            'price_unit': item.get('price', 0.0),
            'name': self._format_line_description(item),
        })

    def _add_shipping_line(self, sale_order, shipping_cost):
        """إضافة الشحن كخط منفصل"""
        shipping_product = self.env['product.product'].search([
            ('default_code', '=', 'SHIPPING')
        ], limit=1)

        if not shipping_product:
            shipping_product = self.env['product.product'].create({
                'name': 'Shipping Cost',
                'default_code': 'SHIPPING',
                'type': 'service',
                'list_price': 0.0,
            })

        self.env['sale.order.line'].create({
            'order_id': sale_order.id,
            'product_id': shipping_product.id,
            'product_uom_qty': 1,
            'price_unit': shipping_cost,
        })

    def _format_order_note(self, order_data):
        """تنسيق ملاحظات الطلب"""
        notes = []

        status = order_data.get('status')
        if status:
            notes.append(f"Status: {status}")

        payment = order_data.get('payment_method')
        if payment:
            notes.append(f"Payment: {payment}")

        return "\n".join(notes)

    def _format_line_description(self, item):
        """تنسيق وصف خط الطلب مع المتغيرات"""
        product_data = item.get('product', {})
        variant_data = item.get('variant')

        name = product_data.get('name', 'Product')

        # إضافة خصائص المتغير (مثل اللون والحجم)
        if variant_data and variant_data.get('variation_props'):
            variants = []
            for prop in variant_data.get('variation_props', []):
                var_type = prop.get('variation', '')
                var_value = prop.get('variation_prop', '')
                if var_type and var_value:
                    variants.append(f"{var_type}: {var_value}")

            if variants:
                name += f" ({', '.join(variants)})"

        return name

    def _find_or_create_customer(self, customer_data):
        """البحث أو إنشاء العميل بناءً على بيانات الطلب"""
        name = customer_data.get('name') or 'Unknown Customer'
        phone = customer_data.get('phone')
        city = customer_data.get('city')
        street = customer_data.get('street')

        domain = [('name', '=', name)]
        if phone:
            domain = ['|', ('phone', '=', phone), ('mobile', '=', phone)]

        partner = self.env['res.partner'].search(domain, limit=1)
        if not partner:
            partner = self.env['res.partner'].create({
                'name': name,
                'phone': phone,
                'mobile': phone,
                'city': city,
                'street': street,
                'customer_rank': 1,
            })
        return partner.id

    # ================= Helper Methods =================
    def _show_error(self, message):
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Error'),
                'message': message,
                'type': 'danger',
                'sticky': True,
            }
        }

    def _show_success(self, message):
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Success'),
                'message': message,
                'type': 'success',
                'sticky': False,
            }
        }

    def _make_slug(self, name, record_id):
        slug = unidecode(name or "product").lower()
        slug = re.sub(r'[^a-z0-9]+', '-', slug).strip('-')
        return f"{slug}-{record_id}"


# ================= Model Extensions =================
class ProductCategory(models.Model):
    _inherit = "product.category"
    image_1920 = fields.Binary("Image")


class ProductTemplate(models.Model):
    _inherit = "product.template"
    easy_order_id = fields.Char(string="Easy Order ID", readonly=True)


class SaleOrder(models.Model):
    _inherit = "sale.order"
    easy_order_id = fields.Char(string="Easy Order ID", readonly=True, index=True)
    easy_order_status = fields.Char(string="Easy Orders Status")
    easy_shipping_cost = fields.Float(string="Shipping Cost")
    easy_total_cost = fields.Float(string="Total Cost from API")