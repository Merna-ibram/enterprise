# -*- coding: utf-8 -*-
{
    'name': "transport",

    'summary': """
        """,

    'description': """
        
    """,

    'author': "MNOOR",
    'website': "http://alrewaa.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['fleet', 'account', 'hr_expense'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence.xml',
        'views/inherit_vehicle.xml',
        'views/transport_views.xml',
        'report/header_footer.xml',
        'report/transport_template.xml',
        'report/transport_report.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
