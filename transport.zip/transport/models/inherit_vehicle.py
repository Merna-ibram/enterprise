# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class FleetVehicle(models.Model):
    _inherit = 'fleet.vehicle'

    is_trailer = fields.Boolean(string="IS Trailer?")
    trailer_type_id = fields.Many2one('trailer.type', string="Types Of Trailer")
    trailer_ids = fields.Many2many('fleet.vehicle', 'f_brand_id', 'model_id', string='Vehicle Trailers')
    location_id = fields.Many2one('transport.location', string='Vehicle Location', readonly=True)
    status = fields.Selection([('empty', 'Empty'),
                               ('loader', 'Loader'),
                               ('under_unloaded', 'Under Unloaded')],
                              string='Vehicle Status', default='empty')
    state = fields.Selection([('available', 'Available'),
                              ('on_trip', 'On Trip'),
                              ('under_maintenance', 'Under Maintenance'),
                              ('broken', 'Broken')],
                             string='Vehicle State', default='available')
    is_broken = fields.Boolean(string="IS Broken?")
    is_under_maintenance = fields.Boolean(string="IS Under Maintenance?")
    analytic_account_id = fields.Many2one('account.analytic.account', string='Analytic Account', required=True)
    fleet_location_ids = fields.One2many('fleet.location', 'vehicle_id', 'Location Logs')
    location_count = fields.Integer(compute="_compute_count", string='Locations')
    taxes_veh_id = fields.Many2one('account.tax', related='company_id.account_sale_tax_id', string='Vehicle Tax')

    def _compute_count(self):
        fleet_location = self.env['fleet.location']
        for record in self:
            record.location_count = fleet_location.search_count([('vehicle_id', '=', record.id)])
        
    def return_action_to_open_new(self):
        """ This opens the xml view specified in xml_id for the current vehicle """
        self.ensure_one()
        xml_id = self.env.context.get('xml_id')
        if xml_id:
            res = self.env['ir.actions.act_window']._for_xml_id('transport.%s' % xml_id)
            res.update(
                context=dict(self.env.context, default_vehicle_id=self.id, group_by=False),
                domain=[('vehicle_id', '=', self.id)]
            )
            return res
        return False
        
    @api.onchange('is_broken')
    def _onchange_vehicle_broken(self):
        if self.is_broken == True:
            self.write({'state': 'broken'})
        elif self.is_broken == False:
            self.write({'state': 'available'})

    @api.onchange('is_under_maintenance')
    def _onchange_vehicle_under_maintenance(self):
        if self.is_under_maintenance == True:
            self.write({'state': 'under_maintenance'})
        elif self.is_under_maintenance == False:
            self.write({'state': 'available'})


class TrailersType(models.Model):
    _name = 'trailer.type'
    _description = 'Trailer Type'

    name = fields.Char(string="Name")


class ProductProduct(models.Model):
    _inherit = 'product.product'

    analytic_account_id = fields.Many2one('account.analytic.account', string='Analytic Account')


# class ResPartner(models.Model):
#     _inherit = 'res.partner'
#
#     is_driver = fields.Boolean(string="IS Driver?")