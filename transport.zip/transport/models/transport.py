# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import datetime
from odoo.exceptions import AccessError, UserError, ValidationError


class Transport(models.Model):
    _name = 'transport.transport'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = 'transport.transport'

    state = fields.Selection(string='State',
                             selection=[('draft', 'Draft'),
                                        ('confirm', 'Confirm'),
                                        ('in_shipping', 'In Loading'),
                                        ('in_way', 'In Way'),
                                        ('unloading', 'Unloading'),
                                        ('done', 'Done'),
                                        ('cancel', 'Cancelled'),
                                        ],
                             readonly=True, copy=False, index=True, tracking=3, default='draft')
    transaction_type = fields.Selection(selection=[('load', 'Load'),
                                                   # ('import', 'Import'),
                                                   # ('export', 'Export'),
                                                   # ('temporary', 'Temporary Export'),
                                                   ], default='load', tracking=True)
    name = fields.Char(string='Transport Reference', required=True, copy=False, readonly=True, index=True,
                       default=lambda self: _('New'))
    date = fields.Date(string='Date', required=True)
    customer_id = fields.Many2one('res.partner', string='Client Name', required=True)
    vendor_id = fields.Many2one('res.partner', string='vendor')
    customer_addr = fields.Char(string='Customer Address', required=True)
    recipient_id = fields.Many2one('res.partner', string='Recipient Name', required=True)
    recipient_addr = fields.Char(string='Recipient Address', required=True)
    employee_id = fields.Many2one('hr.employee', string="Follow-up Employee")
    currency_id = fields.Many2one('res.currency', 'Currency',
                                  default=lambda self: self.env.company.currency_id.id)
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    line_ids = fields.One2many('transport.line', 'transport_id', string='Transport Lines',
                               states={'cancel': [('readonly', True)],
                                       'done': [('readonly', True)],
                                       'confirm': [('readonly', True)],
                                       'in_shipping': [('readonly', True)],
                                       'in_way': [('readonly', True)],
                                       'unloading': [('readonly', True)],
                                       },
                               copy=True,
                               auto_join=True)
    description = fields.Text(string='Description')
    move_id = fields.Many2one('account.move', string="Move")
    expense_ids = fields.One2many('transport.expense.line', 'transport_id')
    crane_ids = fields.One2many('transport.crane', 'transport_id')
    expense_count = fields.Integer(string='Expense Count', compute='get_expense_count')
    invoice_count = fields.Integer(string='Invoice Count', compute='get_expense_count')
    bill_count = fields.Integer(string='Bill Count', compute='get_expense_count')

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            seq_date = None
            if 'date' in vals:
                seq_date = fields.Datetime.context_timestamp(self, fields.Datetime.to_datetime(vals['date']))
            if 'company_id' in vals:
                vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                    'transport.transport', sequence_date=seq_date) or _('New')
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('transport.transport', sequence_date=seq_date) or _('New')
        result = super(Transport, self).create(vals)
        return result

    def unlink(self):
        for order in self:
            if order.state not in ('draft', 'cancel'):
                raise UserError(
                    _('You can not delete a Transport you must first cancel it.'))
        return super(Transport, self).unlink()

    def action_confirm(self):
        for rec in self.line_ids:
            if not rec.vehicle_id:
                raise UserError(
                    _('You can not confirm a Transport Without vehicle.'))
        self.write({'state': 'confirm'})

    def action_in_shipping(self):
        for line in self.line_ids:
            line.write({'date_loading': datetime.now()})
            line.vehicle_id.write({'state': 'on_trip'})
            line.vehicle_id.write({'status': 'loader'})
            for ve_line in line.vehicle_id.trailer_ids:
                ve_line.write({'state': 'on_trip'})
                ve_line.write({'status': 'loader'})
        self.write({'state': 'in_shipping'})

    def action_in_way(self):
        self.write({'state': 'in_way'})

    def action_unloading(self):
        for line in self.line_ids:
            line.write({'date_unload': datetime.now()})
            line.vehicle_id.write({'location_id': line.location_to_id.id})
            line.vehicle_id.write({'status': 'under_unloaded'})
            self.env['fleet.location'].create({'vehicle_id': line.vehicle_id.id,
                                               'location_id': line.location_to_id.id,
                                               'date': datetime.now()})
            for ve_line in line.vehicle_id.trailer_ids:
                ve_line.write({'location_id': line.location_to_id.id})
                ve_line.write({'status': 'under_unloaded'})
                self.env['fleet.location'].create({'vehicle_id': ve_line.id,
                                                   'location_id': line.location_to_id.id,
                                                   'date': datetime.now()})
        self.write({'state': 'unloading'})

    def action_done(self):
        for line in self.line_ids:
            line.vehicle_id.write({'state': 'available'})
            line.vehicle_id.write({'status': 'empty'})
            for ve_line in line.vehicle_id.trailer_ids:
                ve_line.write({'state': 'available'})
                ve_line.write({'status': 'empty'})
        self.write({'state': 'done'})

    def action_cancel(self):
        for transport in self:
            if transport.invoice_count > 0:
                raise UserError(
                    _('You can not Cancel a Transport with invoice.'))
            else:
                self.write({'state': 'cancel'})

    def action_draft(self):
        return self.write({'state': 'draft'})

    def get_expense_count(self):
        self.expense_count = self.env['hr.expense.sheet'].search_count([('transport_id', '=', self.id)])
        self.invoice_count = self.env['account.move'].search_count([('transport_ids', '=', self.id), ('move_type', '=', 'out_invoice')])
        self.bill_count = self.env['account.move'].search_count([('tra_bill_id', '=', self.id), ('move_type', '=', 'in_invoice')])

    def action_create_expense(self):
        if not self.employee_id:
            raise ValidationError("You can not create expense without the employee!!"
                                  "Please add the employee first !!")
        expense_sheet_ids = self.env['hr.expense.sheet'].search([
            ('transport_id', '=', self.id), ('state', 'in', ['draft', 'submit'])
        ])
        if expense_sheet_ids:
            raise UserError(_("The expense is already Pending\n"
                              "Please proceed that expense first"))
        expense = self.env['hr.expense.sheet'].create({
            'name': self.employee_id and self.employee_id.name,
            'employee_id': self.employee_id and self.employee_id.id,
            'transport_id': self.id,
        })
        for tran in self:
            if not tran.expense_ids:
                raise ValidationError("You can not create expense without line!!"
                                      "Please add the product first !!")
            for exp_line in tran.expense_ids:
                self.env['hr.expense'].create({
                    'name': exp_line.product_id and exp_line.product_id.name,
                    'employee_id': tran.employee_id and tran.employee_id.id,
                    'product_id': exp_line.product_id and exp_line.product_id.id,
                    'unit_amount': exp_line.unit_amount or 0.00,
                    'quantity': exp_line.quantity or 0.00,
                    'account_id': exp_line.product_id and exp_line.product_id.property_account_expense_id
                                  and exp_line.product_id.property_account_expense_id.id or False,
                    'sheet_id': expense.id,
                    'analytic_account_id': exp_line.vehicle_id and exp_line.vehicle_id.analytic_account_id and
                                           exp_line.vehicle_id.analytic_account_id.id or False,
                    'payment_mode': 'company_account',
                })

    def action_create_invoice(self):
        """Invoice for Deposit Receive."""
        for tran in self:
            # if tran.amount_total <= 0.0:
            #     raise ValidationError("You can not create Trip invoice without amount!!"
            #                           "Please add trip amount first !!")
            deposit_inv_ids = self.env['account.move'].search([
                ('transport_ids', '=', tran.id), ('move_type', '=', 'out_invoice'),
                ('state', 'in', ['draft', 'open', 'in_payment'])
            ])
            if deposit_inv_ids:
                raise UserError(_("Deposit invoice is already Pending\n"
                                  "Please proceed that deposit invoice first"))
            inv_ser_line = []
            for line in tran.line_ids:
                inv_line_values = {
                    'product_id': False,
                    'name': line.desc_goods or '',
                    'price_unit': line.price_unit or 0.00,
                    'quantity': line.uom_qty,
                    # 'account_id': False,
                    'analytic_account_id': line.vehicle_id and line.vehicle_id.analytic_account_id and
                                           line.vehicle_id.analytic_account_id.id or False,
                    'tax_ids': line.vehicle_id and line.vehicle_id.taxes_veh_id and
                               line.vehicle_id.taxes_veh_id.ids or False,
                }
                inv_ser_line.append((0, 0, inv_line_values))
            inv_values = {
                'partner_id': tran.customer_id and tran.customer_id.id or False,
                'move_type': 'out_invoice',
                'ref': self.name,
                'invoice_date': tran.date,
                'invoice_line_ids': inv_ser_line,
                'transport_ids': self.ids,
            }
            move_id = self.env['account.move'].create(inv_values)
            tran.update({'move_id': move_id})
            form = self.env.ref('account.view_move_form', False)
            return {
                'type': 'ir.actions.act_window',
                'name': "Invoice",
                'res_model': 'account.move',
                'res_id': move_id.id,
                'view_mode': 'form',
                'view_id': form.id,
                'views': [(form.id, 'form')],
            }

    def action_create_bill(self):
        """Bill for Deposit Receive."""
        for tran in self:
            # if tran.amount_total <= 0.0:
            #     raise ValidationError("You can not create Trip invoice without amount!!"
            #                           "Please add trip amount first !!")
            deposit_inv_ids = self.env['account.move'].search([
                ('tra_bill_id', '=', tran.id), ('move_type', '=', 'in_invoice'),
                ('state', 'in', ['draft', 'open', 'in_payment'])
            ])
            if deposit_inv_ids:
                raise UserError(_("Vendor bill is already Pending\n"
                                  "Please proceed that vendor bill first"))
            if not tran.vendor_id:
                raise UserError(_("You can not create vendor bill without supplier"))

            bill_line = []
            for line in tran.crane_ids:
                inv_line_values = {
                    'product_id': line.product_id and line.product_id.id,
                    'name': line.product_id.name or '',
                    'price_unit': line.unit_amount or 0.00,
                    'quantity': line.quantity,
                    'account_id': line.product_id and line.product_id.property_account_expense_id and
                                  line.product_id.property_account_expense_id.id,
                    'analytic_account_id': line.product_id and line.product_id.analytic_account_id and
                                           line.product_id.analytic_account_id.id or False,
                    'tax_ids': line.product_id and line.product_id.supplier_taxes_id and
                               line.product_id.supplier_taxes_id.ids or False,
                }
                bill_line.append((0, 0, inv_line_values))
            bill_values = {
                'partner_id': tran.vendor_id and tran.vendor_id.id or False,
                'move_type': 'in_invoice',
                'ref': self.name,
                'invoice_date': tran.date,
                'invoice_line_ids': bill_line,
                'tra_bill_id': self.id,
            }
            move_id = self.env['account.move'].create(bill_values)
            # tran.update({'move_id': move_id})
            form = self.env.ref('account.view_move_form', False)
            return {
                'type': 'ir.actions.act_window',
                'name': "Bill",
                'res_model': 'account.move',
                'res_id': move_id.id,
                'view_mode': 'form',
                'view_id': form.id,
                'views': [(form.id, 'form')],
            }

    def action_create_multi_invoice(self):
        """Invoice for Deposit Receive."""
        inv_ser_line = []
        for tran in self:
            deposit_inv_ids = self.env['account.move'].search([
                ('transport_ids', '=', tran.id), ('move_type', '=', 'out_invoice'),
                ('state', 'in', ['draft', 'open', 'in_payment'])
            ])
            if deposit_inv_ids:
                raise UserError(_("Deposit invoice is already Pending\n"
                                  "Please proceed that deposit invoice first"))
            for tra in tran:
                for line in tra.line_ids:
                    inv_line_values = {
                        'product_id': False,
                        'name': line.desc_goods or '',
                        'price_unit': line.price_unit or 0.00,
                        'quantity': line.uom_qty,
                        # 'account_id': False,
                        'analytic_account_id': line.vehicle_id and line.vehicle_id.analytic_account_id and
                                               line.vehicle_id.analytic_account_id.id or False,
                        'tax_ids': line.vehicle_id and line.vehicle_id.taxes_veh_id and
                                   line.vehicle_id.taxes_veh_id.ids or False,
                    }
                    inv_ser_line.append((0, 0, inv_line_values))
            inv_values = {
                'partner_id': tran.customer_id[0] and tran.customer_id[0].id or False,
                'move_type': 'out_invoice',
                # 'ref': tran.name[0],
                'invoice_date': tran[0].date,
                'invoice_line_ids': inv_ser_line,
                'transport_ids': self.ids,
              }
        move_id = self.env['account.move'].create(inv_values)
        for tr in self:
            tr.update({'move_id': move_id})
        form = self.env.ref('account.view_move_form', False)
        return {
            'type': 'ir.actions.act_window',
            'name': "Invoice",
            'res_model': 'account.move',
            'res_id': move_id.id,
            'view_mode': 'form',
            'view_id': form.id,
            'views': [(form.id, 'form')],
        }

    def open_expense(self):
        return {
            'name': _('Expense'),
            'domain': [('transport_id', '=', self.id)],
            'view_type': 'form',
            'res_model': 'hr.expense.sheet',
            'view_id': False,
            'view_mode': 'tree,form',
            'type': 'ir.actions.act_window',
        }

    def open_invoice(self):
        return {
            'name': _('Invoice'),
            'domain': [('transport_ids', '=', self.ids), ('move_type', '=', 'out_invoice')],
            'view_type': 'form',
            'res_model': 'account.move',
            'view_id': False,
            'view_mode': 'tree,form',
            'type': 'ir.actions.act_window',
        }

    def open_bill(self):
        return {
            'name': _('Bill'),
            'domain': [('tra_bill_id', '=', self.id), ('move_type', '=', 'in_invoice')],
            'view_type': 'form',
            'res_model': 'account.move',
            'view_id': False,
            'view_mode': 'tree,form',
            'type': 'ir.actions.act_window',
        }


class TransportLine(models.Model):
    _name = 'transport.line'
    _description = 'Transport Line'

    transport_id = fields.Many2one('transport.transport', string='Transport', required=True, ondelete='cascade',
                                   index=True, copy=False)
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    driver_id = fields.Many2one('res.partner', related='vehicle_id.driver_id', string='Driver Name', readonly=False)
    location_form_id = fields.Many2one('transport.location', 'From', required=True)
    location_to_id = fields.Many2one('transport.location', 'To', required=True)
    desc_goods = fields.Char(string='Description Goods')
    waybill = fields.Char(string='Waybill')
    manifest = fields.Char(string='Manifest')
    price_unit = fields.Float('Price', required=True, digits='Product Price', default=0.0)
    container_ids = fields.Char(string='Containers')
    weight = fields.Char(string='Weight',  required=True)
    distance = fields.Char(string='Distance',  required=True)
    uom_qty = fields.Float(string='Quantity', digits='Product Unit of Measure', required=True, default=1.0)
    date_loading = fields.Datetime(string='loading date')
    date_unload = fields.Datetime(string='unload date')
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)

    def unlink(self):
        for line in self:
            if line.transport_id.state != 'cancel':
                if line.transport_id.invoice_count > 0:
                    raise UserError(
                        _('In Transport to delete a transport line, you must first cancel it to delete related line items.'))
        return super(TransportLine, self).unlink()


class TransportLocation(models.Model):
    _name = 'transport.location'
    _description = 'Transport location'

    name = fields.Char()


class Expense(models.Model):
    _name = 'transport.expense.line'
    _description = 'Expense Line'

    transport_id = fields.Many2one('transport.transport', string='Transport', required=True, ondelete='cascade', copy=False)
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle", required=True)
    product_id = fields.Many2one('product.product', domain="[('type', '=', 'service')]")
    unit_amount = fields.Float(string='Unit Price')
    quantity = fields.Float(string='Quantity', required=True, default=1)
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    price_total = fields.Float(compute="_compute_amount", string='Subtotal')

    @api.onchange('quantity', 'unit_amount')
    def _compute_amount(self):
        for line in self:
            line.price_total = line.quantity * line.unit_amount

    def unlink(self):
        for line in self:
            if line.transport_id.state != 'cancel':
                if line.transport_id.expense_count > 0:
                    raise UserError(
                        _('In Transport to delete a Expense line, you must first cancel it to delete related line items.'))
        return super(Expense, self).unlink()


class Crane(models.Model):
    _name = 'transport.crane'
    _description = 'Crane Line'

    transport_id = fields.Many2one('transport.transport', string='Transport', required=True, ondelete='cascade',
                                   copy=False)
    product_id = fields.Many2one('product.product', domain="[('type', '=', 'service')]")
    unit_amount = fields.Float(string='Unit Price')
    quantity = fields.Float(string='Quantity', required=True, default=1)
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    price_total = fields.Float(compute="_compute_amount", string='Subtotal')

    @api.onchange('quantity', 'unit_amount')
    def _compute_amount(self):
        for line in self:
            line.price_total = line.quantity * line.unit_amount

    def unlink(self):
        for line in self:
            if line.transport_id.state != 'cancel':
                if line.transport_id.bill_count > 0:
                    raise UserError(
                        _('In Transport to delete a crane line, you must first cancel it to delete related line items.'))
        return super(Crane, self).unlink()


class AccountInvoice(models.Model):
    _inherit = "account.move"

    transport_ids = fields.One2many('transport.transport', 'move_id', string='Transport', ondelete='cascade', copy=False)
    tra_bill_id = fields.Many2one('transport.transport', string='Bill', ondelete='cascade', copy=False)


class HrExpenseSheet(models.Model):
    _inherit = "hr.expense.sheet"

    transport_id = fields.Many2one('transport.transport', string='Transport', ondelete='cascade', copy=False)
    

class FleetLocation(models.Model):
    _name = 'fleet.location'
    _rec_name = 'date'

    location_id = fields.Many2one('transport.location', 'Location')
    date = fields.Datetime(string='Date', required=True)
    vehicle_id = fields.Many2one('fleet.vehicle')